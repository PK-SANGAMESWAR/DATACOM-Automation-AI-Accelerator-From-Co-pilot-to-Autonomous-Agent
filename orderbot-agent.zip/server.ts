import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Dynamic Lookups (Simulated Firestore logic based on blueprint)
  const mockCustomers: any = {
    "sangameswarpk@gmail.com": { id: "SF-777", name: "Sangu PK", tier: "Platinum", creditLimit: 100000 },
    "sanguchachu@gmail.com": { id: "SF-888", name: "Sangu Chachu", tier: "Gold", creditLimit: 50000 },
    "customer@example.com": { id: "SF-101", name: "Acme Corp", tier: "Gold", creditLimit: 5000 }
  };

  const mockInventory: any = {
    "LAPTOP-01": { stock: 15, price: 1200 },
    "MONITOR-02": { stock: 5, price: 300 }
  };

  app.post("/api/webhook", async (req, res) => {
    try {
      const { email, extractedData } = req.body;

      if (!email || !extractedData) {
        return res.status(400).json({ error: "Email and extractedData are required" });
      }

      const customer = mockCustomers[email];
      const stockItem = mockInventory[extractedData.sku];

      let decision = "APPROVE";
      let reason = "";

      if (!customer) {
        decision = "REJECT";
        reason = "Unknown Customer";
      } else if (!stockItem) {
        decision = "REJECT";
        reason = `SKU ${extractedData.sku} not found in inventory`;
      } else if (stockItem.stock < extractedData.quantity) {
        decision = "REJECT";
        reason = "Insufficient Stock";
      } else if (customer.creditLimit < (stockItem.price * extractedData.quantity)) {
        decision = "REJECT";
        reason = "Credit Limit Exceeded";
      }

      const responseData = {
        success: true,
        decision,
        reason,
        data: {
          customer: customer || { name: "Unknown" },
          stockInfo: stockItem || { stock: 0, price: 0 },
          extractedData
        },
        logs: [
          { step: "Shared Inbox", status: "Received", detail: `Email from ${email}` },
          { step: "Extract PDF API", status: "Success", detail: `Extracted SKU: ${extractedData.sku}` },
          { step: "Query Salesforce API", status: "Success", detail: `Customer: ${customer?.name || "Unknown"}` },
          { step: "Query Sheets API", status: "Success", detail: `Stock: ${stockItem?.stock || 0}` },
          { step: decision === "APPROVE" ? "Send Approval Email" : "Send Reject Email", status: "Success", detail: decision === "APPROVE" ? "Order confirmed" : reason }
        ]
      };

      res.json(responseData);
    } catch (error: any) {
      console.error("Webhook error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
